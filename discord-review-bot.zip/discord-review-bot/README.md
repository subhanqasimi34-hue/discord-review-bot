# Discord Review Bot – Koyeb Ready

## Features
- Discord Gateway (Bot online)
- Slash Commands über Webhook
- MongoDB Unterstützung
- Läuft 24/7 auf Koyeb
- Funktioniert mit UptimeRobot

## Starten
